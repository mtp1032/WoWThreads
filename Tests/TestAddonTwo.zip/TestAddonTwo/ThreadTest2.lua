-- FILE NAME:		ThreadTest2.lua
-- AUTHOR:          Michael Peterson
-- ORIGINAL DATE:   25 May, 2023
local _, TestAddonTwo = ...

local Major ="WoWThreads-1.0"
local thread = LibStub:GetLibrary( Major )
if not thread then 
    return 
end

local sprintf = _G.string.format 

local SIG_ALERT             = thread.SIG_ALERT
local SIG_JOIN_DATA_READY   = thread.SIG_JOIN_DATA_READY
local SIG_TERMINATE         = thread.SIG_TERMINATE
local SIG_METRICS           = thread.SIG_METRICS
local SIG_NONE_PENDING      = thread.SIG_NONE_PENDING

local SUCCESS   = thread.SUCCESS
local FAILURE   = thread.FAILURE
local EMPTY_STR = thread.EMPTY_STR

local main_h    = nil

local function grandChildFunc()
    local signal = SIG_NONE_PENDING
    local DONE = false

    thread:delay( 60 )
    local self_h, selfId = thread:self()
    local parent_h, result = thread:getParent()
    assert( result[1] == SUCCESS, thread:postResult( result ))

    local grandParent_h, result = thread:getParent( parent_h )
    assert( result[1] == SUCCESS, thread:postResult( result ))

    while DONE do
        thread:yield()
        signal, sender_h = getSignal()
        if signal == SIG_TERMINATE then
            DONE = true
        end
    end
    DEFAULT_CHAT_FRAME:AddMessage( sprintf("Grand child thread terminated successully.", selfId ), 0.0, 1.0, 1.0 )
end
local function childFunc()
    local result = { SUCCESS, EMPTY_STR, EMPTY_STR }
    local signal = SIG_NONE_PENDING
    local DONE = false

    -- create a grandChild
    local grandChild_h, result = thread:create( 30, grandChildFunc )
    assert( result[1] == SUCCESS, thread:postResult( result ))

    while not DONE do
        thread:yield()
        signal, sender_h = thread:getSignal()
        if signal == SIG_TERMINATE then
            DONE = true
        end
    end
   
    DEFAULT_CHAT_FRAME:AddMessage( "Child thread terminated successully.", 0.0, 1.0, 1.0 )
end
local function main()
    local result = {SUCCESS, EMPTY_STR, EMPTY_STR}
    local signal = SIG_NONE_PENDING
    local DONE = false
    local childThreads = {}
    

    local child_h, result = thread:create( 60, childFunc )
    assert( result[1] == SUCCESS, thread:postResult( result ))

    thread:delay( 60 )
    while not DONE do
        thread:yield()

        local grandChild_h, result = thread:getParent( child_h )
        assert( result[1] == SUCCESS, thread:postResult( result ))

        result = thread:sendSignal( grandChild_h, SIG_TERMINATE)
        assert( result[1] == SUCCESS, thread:postResult( result ))

        result = thread:sendSignal( child_h, SIG_TERMINATE)
        assert( result[1] == SUCCESS, thread:postResult( result ))

        DONE = true
    end
    DEFAULT_CHAT_FRAME:AddMessage( "[TEST 2] Main thread terminated successully.", 0.0, 1.0, 1.0 )
end
local result = {SUCCESS, EMPTY_STR, EMPTY_STR}
main_h, result = thread:create( 60, main )
assert( result[1] == SUCCESS, thread:postResult( result ))




