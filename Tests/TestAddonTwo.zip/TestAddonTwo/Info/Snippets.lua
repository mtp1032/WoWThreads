-- WoWThreads is the name of the file. Here are the detail
-- about how locales.Lua is loaded.
--
-- Blizz treats the file name as function such as
--    locales.Lua

--    local name = UnitName("player")
--    print( name )

-- So, when the file is "loaded", the name of the file becomes
-- a function to which arguments are passed
function WoWThreads(...)
    local name = UnitName("player")
    print( name )
end
-- In the loading process the "function" WoWThreads() is executed.
WoWThreads()

-- Here's a preview of what a working addon's files look like

-- In WoWThreads.lua
local Addon, thread = ...

thread.SIG_ALERT = dispatch.SIG_ALERT

function thread:sendSignal( signal )
	dispatch:sendSignal( signal )
end
function thread:getSignal()
    return dispatch:getSignal()
end


-- In Dispatch.lua
local Addon, dispatch = ...

dispatch.SIG_ALERT = 1

function dispatch:sendSignal( signal )
end
function dispatch:getSignal()
    return dispatch:getSignal()
end
