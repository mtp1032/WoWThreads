-- FILE NAME:		ThreadTest1.lua
-- AUTHOR:          Michael Peterson
-- ORIGINAL DATE:   25 May, 2023
local Addon, OneOfTestTwo = ...

local sprintf = _G.string.format 

local Major ="WoWThreads-1.0"
local thread = LibStub:GetLibrary( Major )
if not thread then 
    return 
end

local SIG_ALERT             = thread.SIG_ALERT
local SIG_JOIN_DATA_READY   = thread.SIG_JOIN_DATA_READY
local SIG_TERMINATE         = thread.SIG_TERMINATE
local SIG_METRICS           = thread.SIG_METRICS
local SIG_NONE_PENDING      = thread.SIG_NONE_PENDING

local SUCCESS = true
local main_h = nil

local function childFunc()
    local result = { SUCCESS, EMPTY_STR, EMPTY_STR }
    local signal = SIG_NONE_PENDING
    local DONE = false

    local _, selfId = thread:self()
    print( thread:prefix(), sprintf("[%s] Child thread %d now active.", Addon, selfId ))
    while not DONE do
        thread:yield()
        signal, sender_h = thread:getSignal()
        if signal ~= SIG_TERMINATE then
            local sigName = thread:getSignalName( signal )
            if sender_h ~= nil then
                local senderId, result = thread:getId( sender_h)
                print( thread:prefix(), sprintf("[%s] Thread %d recieved %s", Addon, selfId, sigName ))
                thread:sendSignal( sender_h, SIG_TERMINATE)
            end 
        else
            result = thread:sendSignal( sender_h, SIG_TERMINATE )
            assert( result[1] == SUCCESS, sprintf("ASSERT FAILED: %s", result[2]))
            DONE = true
            print( thread:prefix(), sprintf("[%s] Child thread received SIG_TERMINATE.", Addon ))
        end
    end
    print( thread:prefix(), "[TestAddonTwo] Child thread terminated successully.")
end
local function main()
    local signal = SIG_NONE_PENDING
    local DONE = false
    
    local child_h, result = thread:create( 60, childFunc )
    local Id = thread:getId( child_h )
    assert( result[1] == SUCCESS, sprintf("ASSERT FAILED: %s", result[2]))
    thread:delay( 60 )

    result = thread:sendSignal( child_h, SIG_ALERT )
    assert( result[1] == SUCCESS, sprintf("ASSERT FAILED: %s", result[2]))

    while not DONE do
        thread:yield()
        signal, sender_h = thread:getSignal()        
        if signal == SIG_TERMINATE then
            thread:sendSignal( sender_h, SIG_TERMINATE )
            DONE = true
            print( thread:prefix(), "[TestAddonTwo] Main thread recieved SIG_TERMINATE.")
        end
    end
    print( thread:prefix(), "[TestAddonTwo] Main thread terminated successully.")
end
print( thread:prefix(), "*** STARTING TESTS OF TestAddonTwo ***.")

local result = {SUCCESS, EMPTY_STR, EMPTY_STR}
local main_h = nil
local ticks = 20
result, main_h = thread:create( ticks, main, "main_h")
if not result[1] then thread:postResult( result ) end
