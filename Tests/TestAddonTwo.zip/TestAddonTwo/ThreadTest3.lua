-- FILE NAME:		ThreadTest3.lua
-- AUTHOR:          Michael Peterson
-- ORIGINAL DATE:   25 May, 2023
local _, TestAddonTwo = ...

local Major ="WoWThreads-1.0"
local thread = LibStub:GetLibrary( Major )
if not thread then 
    return 
end

local sprintf = _G.string.format 

local SIG_ALERT             = thread.SIG_ALERT
local SIG_JOIN_DATA_READY   = thread.SIG_JOIN_DATA_READY
local SIG_TERMINATE         = thread.SIG_TERMINATE
local SIG_METRICS           = thread.SIG_METRICS
local SIG_NONE_PENDING      = thread.SIG_NONE_PENDING

local SUCCESS   = thread.SUCCESS
local EMPTY_STR = thread.EMPTY_STR

local maxThreads = 100
local childYieldTime = 2
local main_h = nil
local terminated = {}
local function getStats( dataSet, index )
    local sampleSize = #dataSet
    local sum = 0

    -- sum the specified elements
    for i = 1, sampleSize do
        local entry = dataSet[i]
        sum = sum + entry[index]
    end
    
    local mean = sum/sampleSize

    -- calculate the variance
    local diffSquared = 0
    for i = 1, sampleSize do
        local entry = dataSet[i]
        diffSquared = diffSquared + (entry[index] - mean)^2
    end

    local variance = diffSquared/(sampleSize - 1)
    local stdDev = math.sqrt( variance )

    return mean, stdDev

end
local function func()
    local DONE = false
    local threadId = thread:getId()
    local self_h, selfId = thread:self()

    local target = math.random( 20000, 80000)
    while not DONE do
        thread:yield()
        local iterations = 5
        local count = 0
        while count <= iterations do
            local num = 0
            while num <= target do
                num = num + 1
            end
            count = count +1 
        end
        local signal, sender_h = thread:getSignal()
        if signal == SIG_TERMINATE then
            DONE = true
            table.insert( terminated, self_h )
        end
    end
    -- DEFAULT_CHAT_FRAME:AddMessage( sprintf("Child[%d] terminated", selfId), 0.0, 1.0, 1.0 )

end
local function main( maxThreads )
    local result = {SUCCESS, EMPTY_STR, EMPTY_STR}
    local DONE = false
    local threads = {}

    local threadId, result = thread:getId()
    DEFAULT_CHAT_FRAME:AddMessage( sprintf("Main thread Id = %d", threadId), 0.0, 1.0, 1.0 )

    for i = 1, maxThreads do
        threads[i], result = thread:create( childYieldTime, func )
        if not result[1] then thread:postResult( result ) end
    end

    thread:yield()
    for i = 1, maxThreads do
        result = thread:sendSignal( threads[i], SIG_TERMINATE )
        if not result[1] then thread:postResult( result ) end
    end

    if #terminated <= maxThreads then
        thread:yield()
    end
    
    local tableOfEntries = {}
    for i = 1, maxThreads do
        local terminated_h = terminated[i]
        local Id = thread:getId( terminated_h )
        -- thread:printx( sprintf("Getting Congestion metrics for thread[%d]", Id ))
        tableOfEntries[i], result = thread:getCongestionEntry( terminated[i] )
        if not result[1] then thread:postResult( result ) end
        -- thread:printx( sprintf("Got metrics for thread[%d]", Id ))
    end

    -- thread:printx( sprintf("Calculating mean/std"))

    local mean, stdDev = getStats( tableOfEntries, 2 )
    local s = sprintf("%d threads @ %d ticks per thread: Mean congestion %0.2f ms, StdDev %0.3f%%\n", maxThreads, childYieldTime, mean, stdDev*100 )
    thread:postMsg( s )
    -- DEFAULT_CHAT_FRAME:AddMessage( s, 0.0, 1.0, 1.0 )

    thread:postInfo( s )
    DEFAULT_CHAT_FRAME:AddMessage( "[TEST 3] Main thread terminated successully.", 0.0, 1.0, 1.0 )
end

local result = {SUCCESS, EMPTY_STR, EMPTY_STR}
main_h, result = thread:create( 60, main, maxThreads )
assert( result[1] == SUCCESS, sprintf("ASSERT FAILED: %s", result[2]))
