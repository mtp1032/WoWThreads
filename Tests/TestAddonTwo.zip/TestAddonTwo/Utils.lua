-- Utils.lua
-- AUTHOR: Michael Peterson 
-- ORIGINAL DATE: 16 April, 2023 
local _, TestAddonTwo = ...
TestAddonTwo.Utils = {}
utils = TestAddonTwo.Utils
	
local sprintf = _G.string.format

function utils:roundUp( num)
    return math.ceil( num )
end
function utils:roundDown( num )
    return math.floor( num )
end
function utils:nearestInt( num ) -- Rounds down to integer

    local lowerInt = math.floor( num )
    local diff = num - lowerInt
    if diff > 0.5 then
        return math.ceil( num )
    end
    return lowerInt
end

-- calculates the mean, stdDev, and variance of a
-- data set (dataSet). A data set is a linear array
-- of entries, where each entry is a simple array of
-- numbers or an array of tuples.
-- Ex:	array of numbers { a, b, c, e, c, t }
--		table of tuples	 { {a, b}, {c, d} ..., {x, y }
--	param:
--		if index is nil, the dataSet is an array of numbers
--		otherwise index is the index into the element of tuple
--		tuple
function utils:getStats( dataSet, index )
		local sampleSize = #dataSet
		local sum = 0

	thread:print()
	-- sum the specified elements
	for i = 1, sampleSize do
		local entry = dataSet[i]
		sum = sum + entry[index]
	end

	local mean = sum/sampleSize
	
	thread:print()
	-- calculate the variance
	local diffSquared = 0
	for i = 1, sampleSize do
		local entry = dataSet[i]
		diffSquared = diffSquared + (entry[index] - mean)^2
	end

	thread:print()
	-- local n = #dataSet
	local variance = diffSquared/(sampleSize - 1)
	local stdDev = math.sqrt( variance )

	thread:print()
	return mean, stdDev

end
function utils:hexStrToDecNum( hexAddress ) -- convert hex string to decimal number
	local stringNumber = string.sub(hexAddress, 9)
	return( tonumber( stringNumber, 16 ))
end
function utils:copyTable(source, shallow) -- does a shallow copy if shallow == true
    local copy = {}
    for k, v in pairs(source) do
        if type(v) == "table" and not shallow then
            copy[k] = CopyTable(v)
        else
            copy[k] = v
        end
    end
    return copy
end

-- local t = {
-- 	{"foo", 3},
-- 	{"foo", 3},
-- 	{"foo", 3},
-- 	{"foo", 3},
-- 	{"foo", 3},
-- 	{"foo", 3},
-- }

-- local mean, stdDev = utils:meanAndStdDev( t, 2 )
-- print( "mean = ", mean, "stdDev = ", stdDev )